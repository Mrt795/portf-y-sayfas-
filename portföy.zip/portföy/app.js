
// Modal'ı açma fonksiyonu
function openModal(project) {
  var modal = document.getElementById("myModal");
  var modalTitle = document.getElementById("modalTitle");
  var modalDescription = document.getElementById("modalDescription");
  var modalImage = document.getElementById("modalImage");
  // Projeye göre başlık, açıklama ve resim ayarla
  if (project === 'project1') {
    modalTitle.textContent = "🛒 E-Ticaret Web Uygulaması";
    modalDescription.textContent = "Bu e-ticaret web uygulaması, kullanıcıların ürünleri kolayca listeleyebilmesini, sepete ekleyebilmesini ve ödeme işlemleri gerçekleştirebilmesini sağlar. Ürünler kategorilere ayrılmış ve filtrelenmiş şekilde sunulur, böylece kullanıcılar ihtiyaçlarına uygun ürünleri hızlıca bulabilir. Kullanıcı girişi ve üyelik sistemi ile kişisel deneyim sunulurken, güvenli ödeme yöntemleri (kredi kartı, PayPal vb.) ile işlemler tamamlanabilir. Ayrıca, kullanıcılar siparişlerini takip edebilir, geçmiş siparişlerine erişebilir ve sepete ekledikleri ürünlerle kolayca alışveriş yapabilirler. Yönetici paneli üzerinden ürünler eklenebilir, düzenlenebilir ve stok durumu yönetilebilir.";
    modalImage.src = "images/image2.jpg"; // Proje resmi (örnek)
  } else if (project === 'project2') {
    modalTitle.textContent = "📊 Dashboard ve Yönetim Paneli";
    modalDescription.textContent = "Bu proje, bir yönetim paneli uygulaması olarak, kullanıcıların verilerini ve sistemle ilgili istatistikleri gerçek zamanlı olarak dinamik grafiklerle görselleştirir. Kullanıcılar, verilerini tarihsel olarak analiz edebilir, farklı metrikleri inceleyebilir ve grafikler üzerinde etkileşimde bulunabilirler. Panel, kullanıcı erişim yönetimi, rol tabanlı izinler ve şifreli giriş gibi güvenlik önlemleriyle donatılmıştır. Yönetici, sistemi denetleyebilir, kullanıcı hesaplarını yönetebilir ve raporları inceleyerek karar destek süreçlerine katkıda bulunabilir. Ayrıca, uygulama, verileri daha verimli bir şekilde görselleştirebilmek için etkileşimli filtreler ve özelleştirilmiş raporlama araçları sunmaktadır.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project3') {
    modalTitle.textContent = "🎮 Mini JavaScript Oyunları";
    modalDescription.textContent = "Bu projede, HTML, CSS ve JavaScript kullanılarak geliştirilmiş basit ancak eğlenceli browser tabanlı oyunlar bulunmaktadır. Oyunlar, kullanıcıların dikkat ve strateji becerilerini test etmeye yönelik tasarlanmıştır. Hafıza oyunu, çiftleri eşleştirme temalı olup, kullanıcıların hafızalarını zorlar. Sayı tahmin oyunu, kullanıcıların doğru sayıyı tahmin etmeye çalıştığı basit bir matematiksel oyun sunar. Yılan oyunu ise klasik bir oyun olarak, oyuncuların yılanı yönlendirerek yemleri yemesini ve büyüyen yılanla engellere çarpmamaya çalışmasını hedefler. Her oyunun kendi zorluk seviyeleri ve kullanıcı etkileşimleriyle dinamik bir deneyim sunulmaktadır. Ayrıca, oyunlar responsive tasarımla tüm cihazlarda sorunsuz çalışacak şekilde optimize edilmiştir";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project4') {
    modalTitle.textContent = "🧭 Harita Tabanlı Mobil Uygulama";
    modalDescription.textContent = "Bu harita tabanlı mobil uygulama, kullanıcıların kendi konumlarını kaydetmelerine ve her bir lokasyon için not bırakmalarına olanak tanır. Kotlin ile geliştirilen uygulama, kullanıcıların harita üzerinde belirli noktaları işaretlemelerini ve bu noktalara özel hatırlatıcı notlar eklemelerini sağlar. Google Maps API ile entegrasyon sayesinde kullanıcılar harita üzerinde konumlarını görsel olarak takip edebilir, gezdikleri yerler hakkında geri bildirimde bulunabilir ve geçmiş lokasyonlarını kolayca görebilirler. Ayrıca, uygulama, konum tabanlı hatırlatıcılar ve not düzenleme gibi özelliklere de sahip, böylece kullanıcılar harita üzerindeki belirli noktalarda istedikleri zaman anılarını kaydedebilir veya hatırlatıcı oluşturabilirler. Bu uygulama, seyahat, gezi veya iş planlaması yapan kullanıcılar için oldukça faydalıdır.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project5') {
    modalTitle.textContent = "🌐 Kurumsal Yönetim Sistemi";
    modalDescription.textContent = "Bu Java projesi, bir işletme yönetim sistemini simüle etmektedir. Kullanıcı, ürün, sipariş, fatura ve ödeme gibi temel yapılarla birlikte veritabanı bağlantısı, e-posta bildirimi ve raporlama gibi destekleyici bileşenler de içermektedir. Modüler yapısıyla genişletilebilir ve kurumsal uygulamalara uygun bir temel sunar.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project6') {
    modalTitle.textContent = "Call of duty simulator";
    modalDescription.textContent = "Call_of_Duty-Simulator, kullanıcıya bir savaş oyunu deneyimini programlama düzeyinde sunmayı hedefleyen bir .NET (muhtemelen C#) tabanlı projedir. Visual Studio için hazırlanmış .sln dosyası içerdiğinden, yapılandırılmış bir çözüm olarak çalışır. Oyun mekaniklerinin simülasyonunu sağlayan bu proje, oyuncu davranışlarını, silah sistemlerini veya yapay zekayı taklit eden modüller içerebilir. Proje, açık kaynaklı olup MIT lisansı ile lisanslanmıştır; bu da dileyen herkesin projeyi kopyalayıp üzerinde değişiklik yapabileceği anlamına gelir. Kodlar henüz yüklenmemiş olsa da, projenin temel yapısı oluşturulmuş ve GitHub üzerinden erişime sunulmuştur.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project7') {
    modalTitle.textContent = " 💻Film kütüphane sistemi";
    modalDescription.textContent = "Film-Library-Project, Python programlama dili ve Jupyter Notebook ortamı kullanılarak geliştirilmiş bir film kütüphanesi uygulamasıdır. Kullanıcıların film ekleme, silme, güncelleme ve listeleme gibi temel işlemleri gerçekleştirebildiği bu proje, veri yönetimini öğrenmek ve temel düzeyde kullanıcı etkileşimi kurmak isteyenler için uygun bir örnektir. Kodlar .ipynb formatında sunulmuş olup, özellikle eğitim ve sunum amaçlı kullanıma uygundur. Proje açık kaynaklıdır ve MIT lisansı altında paylaşılmıştır, böylece isteyen herkes özgürce kullanabilir ve geliştirebilir.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  } else if (project === 'project8') {
    modalTitle.textContent = "🧭 Banka hesap yönetim sistemi";
    modalDescription.textContent = "Bank-Account-Management-System-Project, temel bankacılık işlemlerini simüle etmek amacıyla Python dilinde ve Jupyter Notebook formatında geliştirilmiş bir projedir. Kullanıcıların hesap açma, para yatırma, para çekme ve bakiye görüntüleme gibi işlemleri yapabildiği bu sistem, finansal işlem mantığını öğrenmek isteyen öğrenciler için öğretici bir örnek sunar. Kodlar interaktif bir ortamda çalışacak şekilde tasarlanmıştır ve açık kaynak MIT lisansı ile herkesin kullanımına sunulmuştur. Eğitim projeleri veya temel yazılım geliştirme becerilerini göstermek isteyenler için uygun bir içerik sunar.";
    modalImage.src = "images/indir.jpeg"; // Proje resmi (örnek)
  }

  modal.style.display = "block"; // Modal'ı göster

  // Kapatma simgesine tıklanırsa, modal'ı kapat
  var closeBtn = document.querySelector('.close');
  closeBtn.addEventListener('click', function() {
    modal.style.display = "none"; // Modal'ı gizle
  });
}

// Modal dışına tıklanarak kapanma işlevi
window.onclick = function(event) {
  var modal = document.getElementById("myModal");
  if (event.target === modal) {
    modal.style.display = "none"; // Modal dışına tıklanırsa, modal'ı kapat
  }
}
